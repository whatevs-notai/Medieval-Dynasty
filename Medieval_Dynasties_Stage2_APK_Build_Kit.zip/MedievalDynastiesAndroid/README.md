# Medieval Dynasties — Android Stage II

A native Android / Kotlin / Jetpack Compose dark medieval-fantasy life simulator.

## Stage I + II playable systems
- Character creation with Peasant, Noble, Merchant, and Scholar origins
- Year-by-year aging, health, happiness, attributes, gold, and reputation
- Actions: train, study, work, pray, socialize, and explore
- Random yearly events and a chronicle log
- Meet a suitor, court a partner, and propose marriage
- Marriage affection and family-time action
- Have children; children age as years pass
- Eldest child is the default heir
- Succession: if the player dies and has children, the eldest inherits and a new generation begins; otherwise the house ends
- Local save/load using Android SharedPreferences, including spouse, courtship, children, and generation data
- Existing Stage I saves remain readable; new fields receive safe defaults

## Build and run
1. Install Android Studio (stable) with Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Run the `app` configuration on an Android device or emulator (Android 8.0 / API 26 or newer).

To create an APK in Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Stage II design notes
- Marriage requires age 16+, courtship of at least 45, and costs 10 gold (the purse cannot go below zero).
- Children require a spouse, age 18+, and are capped at eight.
- Each year, children age by one year. The eldest living listed child inherits first.
- A successor begins at age 16 minimum, with reduced inherited resources and the house name.
- The family systems are intentionally a foundation; expanded personalities, parent/child relationship scores, spouse events, legitimacy, adoption, multiple marriage rules, and a family tree remain future work.

## Next stages
- Stage III: careers, education paths, property, trade, and economy
- Stage IV: court, factions, law, crime, religion, and politics
- Stage V: armies, battles, sieges, tournaments, and travel
- Stage VI: richer NPC simulation, legacy, achievements, balancing, and polish

## Verification
The source was reviewed for integration with the Stage I state and save format. A Gradle build was not run in this environment because a Gradle executable/wrapper is not available here. Please sync and build in Android Studio to confirm against your installed SDK.
