package com.medievaldynasties.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

private val Ink = Color(0xFFE9DFC9)
private val Muted = Color(0xFFB7A98D)
private val Night = Color(0xFF171512)
private val Panel = Color(0xFF28231D)
private val Gold = Color(0xFFC49A52)
private val Blood = Color(0xFF8D3434)
private val Moss = Color(0xFF62724B)

data class Child(val name: String, val age: Int, val health: Int = 80)

data class GameState(
    val name: String = "",
    val house: String = "",
    val origin: String = "Peasant",
    val age: Int = 16,
    val year: Int = 1247,
    val health: Int = 80,
    val happiness: Int = 60,
    val intelligence: Int = 45,
    val strength: Int = 45,
    val charm: Int = 40,
    val gold: Int = 12,
    val reputation: Int = 0,
    val spouseName: String = "",
    val spouseAffection: Int = 0,
    val suitorName: String = "",
    val courtship: Int = 0,
    val children: List<Child> = emptyList(),
    val generation: Int = 1,
    val alive: Boolean = true,
    val log: List<String> = listOf("The bells toll over a cold and hungry kingdom. Your story begins.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("dynasties", MODE_PRIVATE)
        setContent {
            var state by remember { mutableStateOf(loadState(prefs.getString("save", null))) }
            var creating by remember { mutableStateOf(state == null) }
            var game by remember { mutableStateOf(state ?: GameState()) }
            fun persist(s: GameState) {
                game = s
                prefs.edit().putString("save", encode(s)).apply()
            }
            MaterialTheme(colorScheme = darkColorScheme(
                background = Night, surface = Panel, primary = Gold,
                onBackground = Ink, onSurface = Ink, secondary = Moss
            )) {
                Surface(Modifier.fillMaxSize(), color = Night) {
                    if (creating) {
                        CreationScreen(
                            onStart = { name, house, origin ->
                                val start = GameState(
                                    name = name.ifBlank { "A nameless soul" },
                                    house = house.ifBlank { "House Ashen" },
                                    origin = origin,
                                    health = if (origin == "Noble") 88 else 78,
                                    intelligence = if (origin == "Scholar") 65 else 42,
                                    gold = when (origin) { "Noble" -> 90; "Merchant" -> 45; else -> 12 },
                                    reputation = if (origin == "Noble") 10 else 0,
                                    log = listOf("Born beneath a blood-red moon, ${name.ifBlank { "you" }} enters a realm of ruin and old magic.")
                                )
                                persist(start); creating = false
                            }
                        )
                    } else {
                        GameScreen(
                            game = game,
                            onAction = { action -> persist(doAction(game, action)) },
                            onRestart = { creating = true }
                        )
                    }
                }
            }
        }
    }
}

private fun encode(s: GameState): String = JSONObject().apply {
    put("name", s.name); put("house", s.house); put("origin", s.origin)
    put("age", s.age); put("year", s.year); put("health", s.health)
    put("happiness", s.happiness); put("intelligence", s.intelligence)
    put("strength", s.strength); put("charm", s.charm); put("gold", s.gold)
    put("reputation", s.reputation); put("spouseName", s.spouseName)
    put("spouseAffection", s.spouseAffection); put("suitorName", s.suitorName)
    put("courtship", s.courtship); put("generation", s.generation)
    put("children", JSONArray().apply { s.children.forEach { child ->
        put(JSONObject().put("name", child.name).put("age", child.age).put("health", child.health))
    } })
    put("alive", s.alive)
    put("log", JSONArray(s.log))
}.toString()

private fun loadState(raw: String?): GameState? = try {
    if (raw == null) null else JSONObject(raw).let { j ->
        val arr = j.optJSONArray("log") ?: JSONArray()
        val kids = j.optJSONArray("children") ?: JSONArray()
        GameState(
            name=j.optString("name"), house=j.optString("house"), origin=j.optString("origin","Peasant"),
            age=j.optInt("age",16), year=j.optInt("year",1247), health=j.optInt("health",80),
            happiness=j.optInt("happiness",60), intelligence=j.optInt("intelligence",45),
            strength=j.optInt("strength",45), charm=j.optInt("charm",40), gold=j.optInt("gold",12),
            reputation=j.optInt("reputation",0),
            spouseName=j.optString("spouseName", ""), spouseAffection=j.optInt("spouseAffection", 0),
            suitorName=j.optString("suitorName", ""), courtship=j.optInt("courtship", 0),
            generation=j.optInt("generation", 1),
            children=(0 until kids.length()).map { i -> kids.getJSONObject(i).let { Child(it.optString("name"), it.optInt("age"), it.optInt("health",80)) } },
            alive=j.optBoolean("alive",true),
            log=(0 until arr.length()).map { arr.optString(it) }
        )
    }
} catch (_: Exception) { null }

private fun bounded(v: Int) = v.coerceIn(0, 100)
private fun addLog(s: GameState, line: String) = s.copy(log = (listOf(line) + s.log).take(30))

private val suitorNames = listOf("Elowen", "Mira", "Ysabel", "Rowena", "Aveline", "Gareth", "Edric", "Oswin", "Lucan", "Roderic")
private val childNames = listOf("Alys", "Baldwin", "Cecily", "Darian", "Edrin", "Fiora", "Gwen", "Hugh", "Isolde", "Jory")

private fun passAway(s: GameState): GameState {
    val dead = addLog(s.copy(health=0), "${s.name} dies beneath the Black Crown. The house holds its breath.")
    val heir = dead.children.sortedByDescending { it.age }.firstOrNull()
    if (heir == null) return addLog(dead.copy(alive=false), "No acknowledged child remains to inherit. House ${s.house} faces extinction.")
    val next = dead.copy(
        name=heir.name, age=heir.age.coerceAtLeast(16), health=heir.health.coerceAtLeast(35),
        happiness=60, intelligence=bounded(s.intelligence/2+20), strength=bounded(s.strength/2+20),
        charm=bounded(s.charm/2+20), gold=(s.gold/2).coerceAtLeast(0),
        reputation=s.reputation/2, spouseName="", spouseAffection=0, suitorName="", courtship=0,
        children=dead.children.filterNot { it.name == heir.name }, generation=s.generation+1, alive=true
    )
    return addLog(next, "SUCCESSION: ${heir.name}, ${heir.age.coerceAtLeast(16)}, inherits the name and burden of ${s.house}. Generation ${next.generation} begins.")
}

private fun doAction(s: GameState, action: String): GameState {
    if (!s.alive) return s
    return when (action) {
        "Train" -> addLog(s.copy(strength=bounded(s.strength+6), health=bounded(s.health-2), happiness=bounded(s.happiness-2)), "You train with the village guards until your arms tremble. Strength rises.")
        "Study" -> addLog(s.copy(intelligence=bounded(s.intelligence+6), happiness=bounded(s.happiness-1)), "By candlelight, you study forbidden histories and the language of the old empire.")
        "Work" -> addLog(s.copy(gold=s.gold+Random.nextInt(3,10), happiness=bounded(s.happiness-3)), "You labor through the day and earn a few hard-won coins.")
        "Pray" -> addLog(s.copy(happiness=bounded(s.happiness+7), reputation=s.reputation+1), "You kneel before the cracked altar. The silence offers little comfort, but you rise steadier.")
        "Socialize" -> addLog(s.copy(charm=bounded(s.charm+3), happiness=bounded(s.happiness+5)), "You share a cup by the hearth and learn which neighbors can be trusted.")
        "Explore" -> {
            val roll = Random.nextInt(100)
            when {
                roll < 35 -> addLog(s.copy(gold=s.gold+Random.nextInt(8,22), happiness=bounded(s.happiness+3)), "Among the roots of a ruined watchtower, you find a purse of forgotten coin.")
                roll < 65 -> addLog(s.copy(health=bounded(s.health-10), reputation=s.reputation+2), "A pale thing stirs in the marsh. You escape, but not without a wound.")
                else -> addLog(s.copy(intelligence=bounded(s.intelligence+2), reputation=s.reputation+1), "You discover an ancient shrine covered in names that predate the kingdom.")
            }
        }
        "Meet Suitor" -> if (s.age < 16 || s.spouseName.isNotBlank()) s else {
            val candidate = suitorNames.filterNot { it == s.suitorName }.random()
            addLog(s.copy(suitorName=candidate, courtship=10), "At the harvest feast, you meet $candidate. Their eyes linger on you across the firelight.")
        }
        "Court Partner" -> if (s.suitorName.isBlank() || s.spouseName.isNotBlank()) s else {
            val score = bounded(s.courtship + 12 + s.charm/8 + Random.nextInt(0,8))
            addLog(s.copy(courtship=score, happiness=bounded(s.happiness+3)), "You court ${s.suitorName}. Trust grows; courtship is now $score/100.")
        }
        "Propose Marriage" -> if (s.suitorName.isBlank() || s.courtship < 45 || s.spouseName.isNotBlank()) s else {
            addLog(s.copy(spouseName=s.suitorName, spouseAffection=65, suitorName="", courtship=0, gold=(s.gold-10).coerceAtLeast(0), reputation=s.reputation+5), "A vow is spoken before the village shrine. You and ${s.suitorName} are wed. House ${s.house} has a consort.")
        }
        "Have Child" -> if (s.spouseName.isBlank() || s.age < 18 || s.children.size >= 8) s else {
            val name = childNames.random() + if (Random.nextBoolean()) " ${s.house.substringAfterLast(' ')}" else ""
            val child = Child(name, 0)
            addLog(s.copy(children=s.children+child, spouseAffection=bounded(s.spouseAffection+3), happiness=bounded(s.happiness+8)), "A child is born to your house: $name. The midwife says the babe is strong. An heir may one day rise from this cradle.")
        }
        "Family Time" -> if (s.spouseName.isBlank() && s.children.isEmpty()) s else {
            addLog(s.copy(happiness=bounded(s.happiness+8), spouseAffection=bounded(s.spouseAffection+5)), "You gather your family by the hearth. For one night, the old horrors beyond the walls seem far away.")
        }
        "Advance Year" -> advanceYear(s)
        else -> s
    }
}

private fun advanceYear(s: GameState): GameState {
    var n = s.copy(age=s.age+1, year=s.year+1, happiness=bounded(s.happiness+1), children=s.children.map { it.copy(age=it.age+1, health=bounded(it.health + if (it.health < 80) 1 else 0)) })
    val roll = Random.nextInt(100)
    n = when {
        roll < 12 -> addLog(n.copy(health=bounded(n.health-18)), "A fever takes hold during the winter. Your health suffers.")
        roll < 25 -> addLog(n.copy(gold=n.gold+Random.nextInt(5,18)), "A traveling peddler pays well for something you thought worthless.")
        roll < 38 -> addLog(n.copy(reputation=n.reputation+3, happiness=bounded(n.happiness+5)), "You help a family through a hard harvest. Word of your kindness spreads.")
        roll < 49 -> addLog(n.copy(gold=(n.gold-8).coerceAtLeast(0)), "A local tax collector arrives with armed men. The household purse grows lighter.")
        roll < 60 -> addLog(n.copy(intelligence=bounded(n.intelligence+2)), "An old wanderer tells you a tale that changes how you see the world.")
        else -> addLog(n, "Another year passes beneath the long shadow of the Black Crown.")
    }
    if (n.age >= 55 && Random.nextInt(100) < (n.age - 50) * 2) n = addLog(n.copy(health=bounded(n.health-15)), "Age weighs heavily upon your bones.")
    if (n.spouseName.isNotBlank() && Random.nextInt(100) < 8) n = addLog(n.copy(spouseAffection=bounded(n.spouseAffection-5)), "A bitter disagreement unsettles your marriage.")
    if (n.health <= 0) n = passAway(n)
    return n
}

@Composable
private fun CreationScreen(onStart: (String,String,String)->Unit) {
    var name by remember { mutableStateOf("Aldric") }
    var house by remember { mutableStateOf("House Ashen") }
    var origin by remember { mutableStateOf("Peasant") }
    Column(Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("MEDIEVAL DYNASTIES", color=Gold, fontSize=13.sp, letterSpacing=3.sp, fontWeight=FontWeight.Bold)
        Text("Beneath the\nBlack Crown", color=Ink, fontSize=34.sp, lineHeight=38.sp, fontWeight=FontWeight.Black)
        Text("A life is a candle. A dynasty is the shadow it leaves.", color=Muted, fontSize=15.sp)
        Divider(color=Gold.copy(alpha=.45f))
        Text("CREATE YOUR HEIR", color=Gold, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
        OutlinedTextField(name, {name=it}, label={Text("Character name")}, singleLine=true, modifier=Modifier.fillMaxWidth(), colors=fieldColors())
        OutlinedTextField(house, {house=it}, label={Text("House name")}, singleLine=true, modifier=Modifier.fillMaxWidth(), colors=fieldColors())
        Text("ORIGIN", color=Muted, fontSize=12.sp, fontWeight=FontWeight.Bold)
        listOf("Peasant","Noble","Merchant","Scholar").forEach {
            Row(verticalAlignment=Alignment.CenterVertically) {
                RadioButton(selected=origin==it, onClick={origin=it}, colors=RadioButtonDefaults.colors(selectedColor=Gold))
                Text(it, color=Ink)
                Spacer(Modifier.width(8.dp))
                Text(when(it) { "Noble" -> "Gold and influence"; "Merchant" -> "Coin and connections"; "Scholar" -> "A sharper mind"; else -> "Humble beginnings" }, color=Muted, fontSize=12.sp)
            }
        }
        Spacer(Modifier.height(4.dp))
        Button(onClick={onStart(name,house,origin)}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Blood), shape=RoundedCornerShape(8.dp)) {
            Text("BEGIN YOUR LIFE", color=Ink, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
        }
        Text("STAGE I • THE FIRST GENERATION", color=Muted, fontSize=11.sp, letterSpacing=1.sp)
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor=Ink, unfocusedTextColor=Ink, focusedBorderColor=Gold,
    unfocusedBorderColor=Muted, focusedLabelColor=Gold, unfocusedLabelColor=Muted,
    cursorColor=Gold
)

@Composable
private fun GameScreen(game: GameState, onAction:(String)->Unit, onRestart:()->Unit) {
    Column(Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Column {
                Text("MEDIEVAL DYNASTIES", color=Gold, fontSize=11.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
                Text(game.house, color=Ink, fontSize=23.sp, fontWeight=FontWeight.Bold)
            }
            Text("YEAR ${game.year}", color=Muted, fontSize=12.sp)
        }
        CardBox {
            Text(game.name, color=Ink, fontSize=22.sp, fontWeight=FontWeight.Bold)
            Text("${game.origin} • Age ${game.age}", color=Muted, fontSize=13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                Metric("HEALTH",game.health, Blood)
                Metric("HAPPINESS",game.happiness, Gold)
                Metric("STRENGTH",game.strength, Moss)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                MiniStat("Intelligence",game.intelligence)
                MiniStat("Charm",game.charm)
                MiniStat("Gold","${game.gold} ₵")
                MiniStat("Renown",game.reputation)
            }
        }
        if (!game.alive) {
            CardBox {
                Text("THE END OF A LIFE", color=Blood, fontWeight=FontWeight.Black, fontSize=18.sp)
                Text("Your line has ended. The ravens remember what the kingdom forgets.", color=Muted)
                Button(onClick=onRestart, colors=ButtonDefaults.buttonColors(containerColor=Blood)) { Text("Found another house") }
            }
        } else {
            Text("YOUR CHOICES", color=Gold, fontWeight=FontWeight.Bold, letterSpacing=2.sp, fontSize=12.sp)
            ActionButton("Train", "Build strength • may cost health") { onAction("Train") }
            ActionButton("Study", "Increase intelligence") { onAction("Study") }
            ActionButton("Work", "Earn 3–9 coins") { onAction("Work") }
            ActionButton("Pray", "Seek comfort and standing") { onAction("Pray") }
            ActionButton("Socialize", "Improve charm and happiness") { onAction("Socialize") }
            ActionButton("Explore the ruins", "Risk danger for secrets and treasure") { onAction("Explore") }
            Text("BLOODLINE & BONDS", color=Gold, fontWeight=FontWeight.Bold, letterSpacing=2.sp, fontSize=12.sp)
            if (game.spouseName.isNotBlank()) {
                CardBox {
                    Text("Consort: ${game.spouseName}", color=Ink, fontWeight=FontWeight.Bold)
                    Text("Marriage affection: ${game.spouseAffection}/100", color=Muted, fontSize=12.sp)
                    if (game.children.isNotEmpty()) Text("Children: ${game.children.size}", color=Gold, fontSize=12.sp)
                }
                if (game.age >= 18 && game.children.size < 8) ActionButton("Have a child", "Build your line of succession") { onAction("Have Child") }
                ActionButton("Family time", "Strengthen household bonds") { onAction("Family Time") }
            } else if (game.age >= 16) {
                if (game.suitorName.isBlank()) {
                    ActionButton("Meet a suitor", "Attend a feast and seek a match") { onAction("Meet Suitor") }
                } else {
                    CardBox {
                        Text("Courtship: ${game.suitorName}", color=Ink, fontWeight=FontWeight.Bold)
                        Text("Affection and trust: ${game.courtship}/100", color=Muted, fontSize=12.sp)
                    }
                    ActionButton("Court ${game.suitorName}", "Deepen the relationship") { onAction("Court Partner") }
                    ActionButton("Propose marriage", "Requires 45 courtship • costs 10 gold") { onAction("Propose Marriage") }
                }
            }
            if (game.children.isNotEmpty()) {
                CardBox {
                    Text("THE NEXT GENERATION", color=Gold, fontWeight=FontWeight.Bold, fontSize=12.sp)
                    game.children.sortedByDescending { it.age }.forEachIndexed { index, child ->
                        Text("${if (index == 0) "✦ Heir" else "• Child"}: ${child.name} — age ${child.age}", color=if(index==0) Ink else Muted, fontSize=13.sp)
                    }
                    Text("Your eldest child inherits if you die.", color=Muted, fontSize=11.sp)
                }
            }
            Button(onClick={onAction("Advance Year")}, modifier=Modifier.fillMaxWidth().height(52.dp), colors=ButtonDefaults.buttonColors(containerColor=Blood), shape=RoundedCornerShape(8.dp)) {
                Text("AGE ONE YEAR  →", fontWeight=FontWeight.Bold, letterSpacing=1.sp)
            }
        }
        Text("GENERATION ${game.generation} • HOUSE ${game.house.uppercase()}", color=Muted, fontSize=10.sp, letterSpacing=1.sp)
        Text("CHRONICLE", color=Gold, fontSize=12.sp, fontWeight=FontWeight.Bold, letterSpacing=2.sp)
        CardBox {
            game.log.forEachIndexed { i, item ->
                Text("✦  $item", color=if(i==0) Ink else Muted, fontSize=13.sp, lineHeight=19.sp)
                if (i != game.log.lastIndex) Divider(color=Muted.copy(alpha=.15f), modifier=Modifier.padding(vertical=5.dp))
            }
        }
        Text("STAGE II BUILD • Family, courtship, marriage, children, heirs and playable succession. Next: deeper family relations, careers, land, court and war.", color=Muted, fontSize=10.sp, lineHeight=15.sp)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.()->Unit) {
    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(10.dp), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement=Arrangement.spacedBy(7.dp), content=content)
    }
}
@Composable
private fun Metric(label:String, value:Int, color:Color) {
    Column(Modifier.width(88.dp)) {
        Text(label, color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold)
        Text("$value", color=Ink, fontSize=17.sp, fontWeight=FontWeight.Bold)
        LinearProgressIndicator(progress={ value/100f }, modifier=Modifier.fillMaxWidth().height(5.dp), color=color, trackColor=Night)
    }
}
@Composable
private fun MiniStat(label:String, value:Any) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Text("$value", color=Gold, fontWeight=FontWeight.Bold, fontSize=15.sp)
        Text(label, color=Muted, fontSize=10.sp)
    }
}
@Composable
private fun ActionButton(title:String, subtitle:String, onClick:()->Unit) {
    OutlinedButton(onClick=onClick, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(8.dp), colors=ButtonDefaults.outlinedButtonColors(contentColor=Ink), border=androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha=.45f))) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Text(title, fontWeight=FontWeight.SemiBold)
            Text(subtitle, color=Muted, fontSize=10.sp)
        }
    }
}
