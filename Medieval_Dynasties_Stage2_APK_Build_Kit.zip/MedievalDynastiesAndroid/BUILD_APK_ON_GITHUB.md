# Get an installable APK without Android Studio

This project includes a GitHub Actions workflow that builds the debug APK on GitHub's hosted Android build machine.

## Steps (phone or computer)
1. Sign in to GitHub and create a **new empty repository** (for example, `medieval-dynasties`).
2. Extract this ZIP. Upload the **contents of the `MedievalDynastiesAndroid` folder** into the repository root. Keep the `.github/workflows/build-apk.yml` file and its folders; GitHub's web uploader may hide `.github`, so if it does, use GitHub Desktop or upload the workflow through **Add file → Create new file** with the path `.github/workflows/build-apk.yml` and paste its contents.
3. Open the repository's **Actions** tab. Select **Build Medieval Dynasties APK** and press **Run workflow** (or wait for the first push workflow to run).
4. Wait for the workflow to finish with a green check.
5. Open that workflow run and scroll to **Artifacts**. Download `Medieval-Dynasties-debug-apk`.
6. Extract the downloaded artifact ZIP. Tap `app-debug.apk` on your Android phone and approve installation from that source if Android asks.

This is a **debug APK** for personal testing, not a Play Store release. It is not signed with a production release key. Keep the same signing key for future release updates if you later publish it.

## If GitHub reports a build error
Open the failed workflow run and copy the first actual `FAILURE:` section. The project may need a code or dependency fix; do not install an APK unless the workflow successfully produced it.
